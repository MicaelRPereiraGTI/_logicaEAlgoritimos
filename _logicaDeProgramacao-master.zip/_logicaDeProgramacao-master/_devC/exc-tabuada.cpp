#include <stdio.h>
#include <conio.h>

int main(){

	int v1, v2;
	printf("Digite o valor da tabuada desejada: \n");
	scanf("%i", &v1);
	v2 = 1 * v1;
	printf("A tabuada de %i x 1: %i \n", v1, v2);
	v2 = 2 * v1;
	printf("A tabuada de %i x 2: %i \n", v1, v2);
	v2 = 3 * v1;
	printf("A tabuada de %i x 3: %i \n", v1, v2);
	v2 = 4 * v1;
	printf("A tabuada de %i x 4: %i \n", v1, v2);
	v2 = 5 * v1;
	printf("A tabuada de %i x 5: %i \n", v1, v2);
	v2 = 6 * v1;
	printf("A tabuada de %i x 6: %i \n", v1, v2);
	v2 = 7 * v1;
	printf("A tabuada de %i x 7: %i \n", v1, v2);
	v2 = 8 * v1;
	printf("A tabuada de %i x 8: %i \n", v1, v2);
	v2 = 9 * v1;
	printf("A tabuada de %i x 9: %i \n", v1, v2);
	v2 = 10 * v1;
	printf("A tabuada de %i x 10: %i \n", v1, v2);	
	
	return 0;
	
}
